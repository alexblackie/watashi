defmodule SayIt.Router do
  use Plug.Router

  plug :match
  plug :dispatch

  def start_link do
    IO.puts "Router started on 0.0.0.0:4000"
    Plug.Adapters.Cowboy.http __MODULE__, []
  end

  get "/" do
    conn = fetch_params(conn)
    case conn.params do
      %{"name" => user} -> send_resp(conn, 200, "hello #{user}")
      _ -> send_resp(conn, 400, "please provide a ?name=")
    end
  end

  match _ do
    send_resp(conn, 404, "not found")
  end
end

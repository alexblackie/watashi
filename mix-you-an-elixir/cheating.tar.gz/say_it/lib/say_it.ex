defmodule SayIt do
  use Application

  def start(_type, _args) do
    SayIt.Supervisor.start_link
  end

end
